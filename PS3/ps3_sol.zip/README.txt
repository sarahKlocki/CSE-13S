5. Explain your answers (18 points)

Please answer the following questions for each file you wrote as part of this assignment.

1. Making change
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.
I followed the base cases as specified in the given pdf. While amount equates to 0, 1 is returned as there is only 1 way to make change for 0 (which
is with no coins). Then, while amount is less than 0, 0 is returned because there's 0 ways to make change for a negative value. while th maxCoin 
equals 1(this is the same as k=1 in the pdf), you return the count function with the amount parameter minus the value function with maxCoin as the parameter, 
and then the sexond parameter is maxCoin. Then, if none of those conditions are true, then you return the same as maxCoin equatig to 1 and add that to the same exact thing minus 1.



2. Frequency of leading digits
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.



3. Multiplying matrices
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.



4. Merge sort
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

